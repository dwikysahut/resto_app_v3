class Constant {
  static const String baseUrl = "https://restaurant-api.dicoding.dev";
  static const String baseImageUrl =
      "https://restaurant-api.dicoding.dev/images/medium";
}
