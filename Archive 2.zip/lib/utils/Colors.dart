import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const main = Color(0xFFF1F6F7);
  static const accentColor = Color(0xFFFF6F61);
  static const bg = Color(0xFF003366);
}
